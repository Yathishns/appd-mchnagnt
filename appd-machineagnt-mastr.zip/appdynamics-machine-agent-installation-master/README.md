# appdynamics-machine-agent-installation

## NAME
appdynamics-machine-agent-installation
configure_machineagent.sh
## SYNOPIS
Configures and starts the appdynamics machine agent
## DESCRIPTION
```
Using property file and service scripts installs exports configuration and starts the appdynamics machine agent.
The Standalone Machine Agent (Machine Agent) collects basic hardware metrics. The Machine Agent is a Java program that has an extensible architecture enabling you to supplement the basic metrics reported in the AppDynamics Controller UI with your own custom metrics. The Machine Agent is also the delivery vehicle for AppDynamics Server Monitoring, which provides an expanded set of hardware metrics and additional monitoring capability.
```
## OPTIONS
```
Properties are stored in a key value pairs format in the machineagnet.props. Stored In the same directory to the script file.

These values should not be changed:
  * AGENT_HOME="/opt/appd/machineagent"
  * SIM=true
```
## NOTES
The current implimentation of this configuration script does not add the machine agent the Profile.d and therefore the machine agent may not be restarted if the host machine is restarted.
## INSTALLATION
### Step 1.
```
Pull this repo to the target host

git clone https://alm-github.systems.uk.hsbc/HDSS-Monitoring-Tooling/appdynamics-machine-agent-installation.git
OR
Download the zip of the repsitory
https://alm-github.systems.uk.hsbc/HDSS-Monitoring-Tooling/appdynamics-machine-agent-installation/archive/master.zip

If scripts are downloaded, extract and rename the zip file to "appdynamics-machine-agent-installation"
```
### Step 2.
```
Example command for copying file to a target host
# Staring on a local machine, within a folder containing the appdynamics-machine-agent-installation/ folder from git
# Run the following with your own user account [user] that has access to the bastion server and target host
  $ scp -r appdynamics-machine-agent-installation/ [user]@[bastion-ip]:/tmp
  $ ssh [user]@[bastion-ip]
  $ scp -r /tmp/appdynamics-machine-agent-installation/ [hostname]:/tmp
  $ ssh [hostname]
  $ dzdo su - appdmon
  $ cp -r /tmp/appdynamics-machine-agent-installation/ /home/appdmon
  $ cd /home/appdmon/appdynamics-machine-agent-installation/

Check the file permissions on the folder and scripts
 Owner: appdmon
 Group: appdmongrp
  Mode: 755
```
### Step 3.
Make sure all the values are correct and are placed under the correct controller.
Examples of PLTE configurations can be found in the descriptio
### Step 4.
```
Run the installation script, with the relevant option.

# Check the contents of the configuration files

$ ./configure_machineagent.sh

# Follow the on screen instructions
```
## INSTALLATION [FOR ADMIN]
```
In order to add the machine agent as a service the daemonse_me.sh script will need to be ran.

AS ROOT
$ cd /home/appdmon/appdynamics-machine-agent-installation/
$ ./daemonize_me.sh
 ```

## Author
Written by Appdynamics
## Copyright
HSBC Copyright
