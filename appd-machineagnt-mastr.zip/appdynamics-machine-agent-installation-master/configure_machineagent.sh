#! /bin/bash

checkXcode () {
    # Tests for non-zero exit codes, then quits with a custom message if necessary
    # Usage: "error_check $?" or "error_check $? 'exit message'"
    local errorlvl="$1"
    local errormsg="$2"
    if [[ -z "$errormsg" ]]; then
    local errormsg=$'\n''###'" Error detected, exiting "'###'
    fi
    if [[ "$errorlvl" -ne 0 ]] || [[ -z "$errorlvl" ]]; then
    echo errormsg:"$errormsg"
    exit 1
    fi
}


###############
# Main Script #
###############
clear

if [ "$(whoami)" != "$(whoami)" ]; then
  echo "======================================================================="
  printf '%10s\n' 'Please run as appdmon!'
  echo "======================================================================="
  exit
fi

echo "========================================================================="
printf '%10s\n' 'STARTING CONFIGURATION FOR APPDYNAMIC MACHINEAGENT'
echo "========================================================================="

PWD=$(pwd)

PROPFILE=$PWD/machineagent.props
if [ ! -f ${PROPFILE} ]; then
   echo "Properties File Missing...."
   exit 1
else
   source ${PROPFILE} >/dev/null 2>&1
fi

echo "Checking Property file:"
for line in $(grep "=" ${PROPFILE})
do
        V1=$(echo $line |cut -d"=" -f1)
        V2=$(echo $line |cut -d"=" -f2)
        [[ -z $V2 ]] && echo "Error: \$$V1 can not be null - please check prop file" && exit 1
done


# Create agent directory
if [ ! -d /opt/appd/machineagent ] ; then

  mkdir -p /opt/appd/machineagent
  chown appdmon:appdmongrp /opt/appd/machineagent
  unzip -o -qq "$PWD"/"$new_agent_archive" -d "/opt/appd/machineagent"
  checkXcode "$?" "unzip failed"

else
  mv -f /opt/appd/machineagent /opt/appd/machineagent-$(date +%Y%m%d%H%M%S).bk
  checkXcode "$?" "backp failed"
  mkdir -p /opt/appd/machineagent
  chown appdmon:appdmongrp /opt/appd/machineagent

  echo 'Unpacking binaries '
  unzip -o -qq "$PWD"/"$new_agent_archive" -d "/opt/appd/machineagent"
  checkXcode "$?" "unzip failed"
fi

# Check for machineagent directory:
if [ ! -d /opt/appd/machineagent/bin ] ; then
   echo "ERROR:missing files: Please check that machineagent.tgz was copied to /opt/appd/"
   exit 1
fi

if [ -f $PWD/machineagent_template ] ; then
   cp $PWD/machineagent_template $AGENT_HOME/scripts/machineagent
else
   echo "ERROR:File not found: $PWD/machineagent_template"
fi

# Updating controller.xml
if [ ! -f ${AGENT_HOME}/conf/controller-info.xml ] ; then
   echo "ERROR:File not found: ${AGENT_HOME}/conf/controller-info.xml"
   exit 1
fi
echo "Updating ${AGENT_HOME}/conf/controller-info.xml"

# updating controller.xml
controller_info="${AGENT_HOME}/conf/controller-info.xml"

sed -i "s/controller-host>.*<\/controller-host/controller-host\>"$CONT_HOST"\<\/controller-host/" "$controller_info"
sed -i "s/controller-port>.*<\/controller-port/controller-port\>"$CONT_PORT"\<\/controller-port/" "$controller_info"
sed -i "s/account-name>.*<\/account-name/account-name\>"$ACCT_NAME"\<\/account-name/" "$controller_info"
sed -i "s/account-access-key>.*<\/account-access-key/account-access-key\>"$ACCT_KEY"\<\/account-access-key/" "$controller_info"
sed -i "s/sim-enabled>.*<\/sim-enabled/sim-enabled\>"$sim_enabled"\<\/sim-enabled/" "$controller_info"
sed -i "s/controller-ssl-enabled>.*<\/controller-ssl-enabled/controller-ssl-enabled\>"$ssl_enabled"\<\/controller-ssl-enabled/" "$controller_info"

checkXcode $? "Configuration Variable Insertion Unsuccessful"

# Copy template start script:
cp $PWD/machineagent_template $AGENT_HOME/scripts/machineagent
chown appdmon:appdmongrp $AGENT_HOME/scripts/machineagent
chmod u+x $AGENT_HOME/scripts/machineagent

# update machineagent
if [ ! -f ${AGENT_HOME}/scripts/machineagent ] ; then
   echo "ERROR:File not found: ${AGENT_HOME}/scripts/machineagent"
   exit 1
fi
echo "Updating ${AGENT_HOME}/scripts/machineagent"
perl -pi -e 's/proxyHost=.*"/proxyHost='$PROXYHOST'"/' ${AGENT_HOME}/scripts/machineagent
perl -pi -e 's/proxyPort=.*"/proxyPort='$PROXYPORT'"/' ${AGENT_HOME}/scripts/machineagent

# Create tmp directory:
if [ ! -d ${AGENT_HOME}/tmp ]; then
   mkdir $AGENT_HOME/tmp
   chown appdmon:appdmongrp $AGENT_HOME/tmp
fi

echo "Installation Completed"

echo '========================================================================='
echo '    To daemonsie the machine agent run daemonize.sh as ROOT'
echo '========================================================================='
