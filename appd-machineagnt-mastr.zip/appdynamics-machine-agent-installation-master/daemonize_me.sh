###############
# Main Script #
###############
clear

if [ -d "/etc/init/machineagent" ]; then
  echo "======================================================================="
  printf '%10s\n' 'Daemonization had been done. Have a nice day!'
  echo "======================================================================="
  exit
fi

if [ "$(whoami)" != "root" ]; then
  echo "======================================================================="
  printf '%10s\n' 'Please run as root!'
  echo "======================================================================="
  exit
fi

echo "========================================================================="
printf '%10s\n' 'DAEMONISING THE APPDYNAMIC MACHINEAGENT'
echo "========================================================================="

PWD=$(pwd)


cd /etc/init.d
ln -s /opt/appd/machineagent/scripts/machineagent

chkconfig --add machineagent
chkconfig  machineagent on
chkconfig --list | grep -i machineagent
